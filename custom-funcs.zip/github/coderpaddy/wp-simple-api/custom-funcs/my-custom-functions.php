<?php
/**
 * Plugin Name: My Custom Functions
 * Plugin URI: https://coderpaddy.com
 * Description: This is an awesome custom plugin with functionality that I'd like to keep when switching things.
 * Author: Your Name
 * Author URI: https://coderpaddy.com
 * Version: 0.1.0
 */

/* Place custom code below this line. */


function cp_api_pass_register_settings() {
    add_option( 'cp_api_pass_option_name', 'The password for the api.');
    register_setting( 'cp_api_pass_options_group', 'cp_api_pass_option_name', 'cp_api_pass_callback' );
 }
add_action( 'admin_init', 'cp_api_pass_register_settings' );

function cp_api_pass_register_options_page() {
    add_options_page('CP API Options', 'Set API Key', 'manage_options', 'cp_api_pass', 'cp_api_pass_options_page');
  }
add_action('admin_menu', 'cp_api_pass_register_options_page');

function cp_api_pass_options_page()
{
?>
  <div>
  <?php screen_icon(); ?>
  <h2>Coder Paddy API Settings</h2>
  <form method="post" action="options.php">
  <?php settings_fields( 'cp_api_pass_options_group' ); ?>
  <h3>Change the API Key</h3>
  <table>
  <tr valign="top">
  <th scope="row"><label for="cp_api_pass_option_name">Key</label></th>
  <td><input type="text" id="cp_api_pass_option_name" name="cp_api_pass_option_name" value="<?php echo get_option('cp_api_pass_option_name'); ?>" /></td>
  </tr>
  </table>
  <?php  submit_button(); ?>
  </form>
  <?php echo get_option('cp_api_pass_option_name'); ?>
  </div>
<?php
}


function my_awesome_func( $data ) {
    $test_pass = $data['passwd'];
    $act_pass = get_option('cp_api_pass_option_name');
    if ( $test_pass == $act_pass ) {
        $post_data = [
            "post_author" => $data['post_author'],
            "post_content" => $data['post_content'],
            "post_title" => wp_strip_all_tags( $data['post_title'] ),
            "post_status" => $data['post_status'],
            "post_type" => $data['post_type'],
        ];
        $post_success = wp_insert_post( $post_data, true );
        update_post_meta( $post_id, '_visibility', 'visible' );
        update_post_meta( $post_id, '_stock_status', $data['post_stock_status']);
        update_post_meta( $post_id, '_price', $data['post_price'] );
        if ( $post_success == 0 ) {
            return null;
        } else {
        
        return get_post($post_success);
        }

    } else {
        return "password wrong";
    }
  }

add_action( 'rest_api_init', function () {
    register_rest_route( 'cp-api/v1', '/makepost/', array(
        'methods' => 'POST',
        'callback' => 'my_awesome_func',
    ) );
} );


/* Place custom code above this line. */

?>